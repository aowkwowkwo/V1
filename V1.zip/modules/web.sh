#!/bin/bash

# Clear screen
clear

# Warna
green='\e[1;32m'
tosca='\e[1;36m'
reset='\e[0m'

# Banner (lurus, green & tosca)
echo -e "${green}██╗███╗   ██╗███████╗███████╗██████╗ ███╗   ██╗ █████╗ ██╗      ██████╗ ${tosca} ██████╗ ██╗    ██╗███╗   ██╗██╗      ██████╗  █████╗ ██████╗"
echo -e "${green}██║████╗  ██║██╔════╝██╔════╝██╔══██╗████╗  ██║██╔══██╗██║      ██╔══██╗${tosca}██╔═══██╗██║    ██║████╗  ██║██║     ██╔═══██╗██╔══██╗██╔══██╗"
echo -e "${green}██║██╔██╗ ██║█████╗  █████╗  ██████╔╝██╔██╗ ██║███████║██║█████╗██║  ██║${tosca}██║   ██║██║ █╗ ██║██╔██╗ ██║██║     ██║   ██║███████║██║  ██║"
echo -e "${green}██║██║╚██╗██║██╔══╝  ██╔══╝  ██╔══██╗██║╚██╗██║██╔══██║██║╚════╝██║  ██║${tosca}██║   ██║██║███╗██║██║╚██╗██║██║     ██║   ██║██╔══██║██║  ██║"
echo -e "${green}██║██║ ╚████║██║     ███████╗██║  ██║██║ ╚████║██║  ██║███████╗ ██████╔╝${tosca}╚██████╔╝╚███╔███╔╝██║ ╚████║███████╗╚██████╔╝██║  ██║██████╔╝"
echo -e "${green}╚═╝╚═╝  ╚═══╝╚═╝     ╚══════╝╚═╝  ╚═╝╚═╝  ╚═══╝╚═╝  ╚═╝╚══════╝ ╚═════╝ ${tosca} ╚═════╝  ╚══╝╚══╝ ╚═╝  ╚═══╝╚══════╝ ╚═════╝ ╚═╝  ╚═╝╚═════╝${reset}"

# Input website
echo -e "\n${green}[INPUT]${reset} Masukkan URL Website target:"
read -p ">> " url

# Ambil nama domain dari URL
domain=$(echo "$url" | sed 's|https\?://||' | sed 's|/.*||')

# Download website
echo -e "\n${tosca}[INFO]${reset} Mendownload website, mohon tunggu..."
wget --mirror --convert-links --adjust-extension --page-requisites --no-parent "$url"

# Output hasil
echo -e "\n${green}[SELESAI]${reset} Website berhasil didownload ke folder: ${tosca}$domain${reset}"
echo -e "Ketik perintah berikut:"
echo -e "${green}cd $domain${reset}"
echo -e "Lalu kamu bisa lihat source code-nya di sana."
