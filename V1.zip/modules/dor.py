import os

BASHRC = os.path.expanduser("~/.bashrc")
TAG = "# [TERMUX_IMAGE_VIEW]"

def show_menu():
    print("""
╔══════════════════════════╗
║   TERMUX IMAGE SETTER    ║
╠══════════════════════════╣
║ 1. Ubah tampilan pakai foto (.jpg/.png)
║ 2. Hapus tampilan (hapus kode di .bashrc)
║ 3. Ganti foto tampilan Termux
╚══════════════════════════╝
""")

def append_bashrc(image_path):
    with open(BASHRC, "a") as f:
        f.write(f"\n{TAG}\ncatimg \"{image_path}\"\n{TAG}\n")
    print("[✓] Foto berhasil diterapkan ke Termux")

def remove_old():
    if not os.path.exists(BASHRC):
        print("[-] .bashrc tidak ditemukan")
        return

    with open(BASHRC, "r") as f:
        lines = f.readlines()

    new_lines = []
    skip = False
    for line in lines:
        if TAG in line:
            skip = not skip
            continue
        if not skip:
            new_lines.append(line)

    with open(BASHRC, "w") as f:
        f.writelines(new_lines)

    print("[✓] Tampilan foto dihapus dari Termux")

def pilih_foto():
    path = input("Masukkan path lengkap atau nama file (cth: kontol.jpg): ").strip()
    full_path = os.path.abspath(path)
    if os.path.exists(full_path):
        return full_path
    else:
        print("[-] File tidak ditemukan.")
        return None

if __name__ == "__main__":
    os.system("clear")
    show_menu()
    pilihan = input("Pilih opsi (1/2/3): ").strip()

    if pilihan == "1":
        remove_old()
        foto = pilih_foto()
        if foto:
            append_bashrc(foto)

    elif pilihan == "2":
        remove_old()

    elif pilihan == "3":
        remove_old()
        foto = pilih_foto()
        if foto:
            append_bashrc(foto)

    else:
        print("[-] Pilihan tidak valid.")
