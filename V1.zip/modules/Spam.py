import os
import requests
import time
from colorama import Fore, Style

# Clear layar & tampilkan banner
os.system("clear")
banner = f"""{Fore.GREEN}  
████████╗███████╗██╗     ███████╗  
╚══██╔══╝██╔════╝██║     ██╔════╝  
   ██║   █████╗  ██║     █████╗    
   ██║   ██╔══╝  ██║     ██╔══╝    
   ██║   ███████╗███████╗███████╗  
   ╚═╝   ╚══════╝╚══════╝╚══════╝   
{Style.RESET_ALL}  
🔥 Telegram Auto Spam Brutal By InfernalXploit 🔥  
{Fore.YELLOW}Author: InfernalXploit{Style.RESET_ALL}  
"""  
print(banner)

# Input ID bot & token
bot_token = input(f"{Fore.CYAN}Masukkan Token Bot Telegram: {Style.RESET_ALL}")
chat_id = input(f"{Fore.CYAN}Masukkan ID Chat/Grup: {Style.RESET_ALL}")

# Pilih kirim pesan atau foto
print(f"\n{Fore.MAGENTA}[1] Kirim Pesan\n[2] Kirim Foto/Document{Style.RESET_ALL}")
choice = input(f"{Fore.CYAN}Pilih (1/2): {Style.RESET_ALL}")

if choice == "1":
    message = input(f"{Fore.CYAN}Masukkan Pesan: {Style.RESET_ALL}")
elif choice == "2":
    file_path = input(f"{Fore.CYAN}Masukkan Path Foto/Document: {Style.RESET_ALL}")

jumlah = int(input(f"{Fore.CYAN}Masukkan Jumlah Pengiriman: {Style.RESET_ALL}"))

# Fungsi kirim pesan
def send_message():
    url = f"https://api.telegram.org/bot{bot_token}/sendMessage"
    data = {"chat_id": chat_id, "text": message}
    response = requests.post(url, data=data)
    return response.json()

# Fungsi kirim foto atau file
def send_file():
    url = f"https://api.telegram.org/bot{bot_token}/sendDocument"
    files = {"document": open(file_path, "rb")}
    data = {"chat_id": chat_id}
    response = requests.post(url, files=files, data=data)
    return response.json()

# Loop kirim sesuai jumlah yang dimasukkan
for i in range(jumlah):
    if choice == "1":
        result = send_message()
    elif choice == "2":
        result = send_file()

    if result.get("ok"):
        print(f"{Fore.GREEN}[{i+1}] Sukses terkirim!{Style.RESET_ALL}")
    else:
        print(f"{Fore.RED}[{i+1}] Gagal terkirim!{Style.RESET_ALL}")

    time.sleep(2)  # Delay biar gak terlalu cepat
