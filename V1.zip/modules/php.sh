#!/bin/bash

# Warna
red='\e[31m'
green='\e[32m'
white='\e[37m'
cyan='\e[36m'
reset='\e[0m'

clear
echo -e "${cyan}╔══════════════════════════════════════╗"
echo -e "${white}║       InfernalXploit PHP Encoder     ║"
echo -e "${red}║           Powered by DarkTr4ce       ║"
echo -e "${cyan}╚══════════════════════════════════════╝${reset}"

read -p "$(echo -e ${white}[?] Masukkan file PHP yang ingin diencode: ${reset})" input
if [[ ! -f "$input" ]]; then
    echo -e "${red}[!] File tidak ditemukan!${reset}"
    exit 1
fi

read -p "$(echo -e ${white}[?] Nama file output (.php): ${reset})" output
if [[ "${output: -4}" != ".php" ]]; then
    echo -e "${red}[!] Output harus berekstensi .php${reset}"
    exit 1
fi

encoded=$(base64 "$input" | tr -d '\n')
echo "<?php eval(base64_decode('$encoded')); ?>" > "$output"

echo -e "${green}[✓] Berhasil encode! File output: $output${reset}"
