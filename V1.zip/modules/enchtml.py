import os
import base64

def clear():
    os.system('cls' if os.name == 'nt' else 'clear')

def banner():
    clear()
    print("\033[96m" + "="*65)
    print("\033[91m    ██╗███╗   ██╗███████╗███████╗██████╗ ███╗   ██╗ ")
    print("\033[91m    ██║████╗  ██║██╔════╝██╔════╝██╔══██╗████╗  ██║ ")
    print("\033[97m    ██║██╔██╗ ██║█████╗  █████╗  ██████╔╝██╔██╗ ██║ ")
    print("\033[97m    ██║██║╚██╗██║██╔══╝  ██╔══╝  ██╔═══╝ ██║╚██╗██║ ")
    print("\033[91m    ██║██║ ╚████║███████╗███████╗██║     ██║ ╚████║ ")
    print("\033[91m    ╚═╝╚═╝  ╚═══╝╚══════╝╚══════╝╚═╝     ╚═╝  ╚═══╝ ")
    print("\033[96m" + "="*65)
    print("\033[97m       ENCODED HTML GENERATOR by \033[91mInfernal\033[97mXploit")
    print("\033[96m" + "="*65 + "\033[0m")

def encode_html(input_file, output_file):
    try:
        with open(input_file, "rb") as f:
            original_html = f.read()
        encoded = base64.b64encode(original_html).decode()

        result = f"""
<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <title>Encoded HTML</title>
  <script>
    function decodeAndInject() {{
        var encoded = "{encoded}";
        var decoded = atob(encoded);
        document.write(decoded);
    }}
    window.onload = decodeAndInject;
  </script>
</head>
<body>
</body>
</html>
"""
        with open(output_file, "w") as f:
            f.write(result)
        print(f"\033[92m[✓] Sukses encode: \033[96m{output_file}\033[0m")
    except Exception as e:
        print(f"\033[91m[!] Gagal encode {input_file}: {e}\033[0m")

def encode_all_html():
    html_files = [f for f in os.listdir() if f.endswith(".html") and not f.startswith("encoded_")]
    if not html_files:
        print("\033[91m[!] Tidak ada file .html ditemukan.\033[0m")
        return

    for html in html_files:
        output_name = f"encoded_{html}"
        encode_html(html, output_name)

if __name__ == "__main__":
    banner()
    print("\n\033[96m[1] Encode satu file HTML")
    print("[2] Encode semua file .html dalam folder\033[0m\n")
    pilihan = input("\033[97m[?] Pilih opsi (1/2): \033[0m")

    if pilihan == "1":
        input_file = input("\033[97m[?] Nama file HTML asli: \033[0m")
        output_file = input("\033[97m[?] Nama file output (misal: deface.html): \033[0m")
        encode_html(input_file, output_file)
    elif pilihan == "2":
        encode_all_html()
    else:
        print("\033[91m[!] Pilihan tidak valid.\033[0m")
